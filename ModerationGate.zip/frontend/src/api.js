const API_BASE = import.meta.env.VITE_API_BASE_URL || "http://localhost:8789";

async function handleResponse(res) {
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `request failed (${res.status})`);
  return data;
}

export async function moderate(message) {
  const res = await fetch(`${API_BASE}/moderate`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ message }),
  });
  return handleResponse(res);
}

export async function getFlaggedLog() {
  const res = await fetch(`${API_BASE}/admin/flagged`);
  return handleResponse(res);
}

export async function clearFlaggedLog() {
  const res = await fetch(`${API_BASE}/admin/flagged`, { method: "DELETE" });
  return handleResponse(res);
}
