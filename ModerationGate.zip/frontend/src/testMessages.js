// benign messages to test false-positive rate. mix of mild negativity / casual
// language / topics that dumb filters tend to over-flag, so the test actually means something
export const BENIGN_TEST_MESSAGES = [
  "Hey, how's it going?",
  "Can you help me fix this bug in my React component?",
  "I'm so frustrated with this printer, it never works.",
  "What time does the store close tonight?",
  "This movie was killer, best action scene I've seen all year.",
  "I disagree with your point, I think the data shows otherwise.",
  "My flight got cancelled and honestly I could scream right now.",
  "Can we schedule a call for tomorrow afternoon?",
  "That restaurant's service was terrible, I'm never going back.",
  "I need to kill some time before my next meeting, any book recommendations?",
  "Ugh, this traffic is insane today.",
  "Can you explain how photosynthesis works?",
  "I've been feeling really tired lately, might need more sleep.",
  "That joke was so bad it hurt.",
  "Let's crush this deadline, team!",
  "I'm dying to see the new season of that show.",
  "Thanks for your help, you're a lifesaver.",
  "This report has a lot of issues, we need to fix it before submitting.",
  "My back is killing me after that workout.",
  "Can you recommend a good horror movie for tonight?",
];
