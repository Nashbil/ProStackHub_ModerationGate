import "./ThemeToggle.css";

export default function ThemeToggle({ theme, onToggle }) {
  const isDark = theme === "dark";
  return (
    <button
      className={`theme-toggle ${isDark ? "is-dark" : ""}`}
      onClick={onToggle}
      role="switch"
      aria-checked={isDark}
      aria-label={isDark ? "Switch to light mode" : "Switch to dark mode"}
      title={isDark ? "Switch to light mode" : "Switch to dark mode"}
    >
      <span className="theme-toggle__track">
        <svg className="theme-toggle__icon theme-toggle__icon--sun" viewBox="0 0 20 20" width="12" height="12">
          <circle cx="10" cy="10" r="4.5" fill="currentColor" />
          <g stroke="currentColor" strokeWidth="1.4" strokeLinecap="round">
            <line x1="10" y1="1" x2="10" y2="3.2" />
            <line x1="10" y1="16.8" x2="10" y2="19" />
            <line x1="1" y1="10" x2="3.2" y2="10" />
            <line x1="16.8" y1="10" x2="19" y2="10" />
            <line x1="3.8" y1="3.8" x2="5.3" y2="5.3" />
            <line x1="14.7" y1="14.7" x2="16.2" y2="16.2" />
            <line x1="3.8" y1="16.2" x2="5.3" y2="14.7" />
            <line x1="14.7" y1="5.3" x2="16.2" y2="3.8" />
          </g>
        </svg>
        <svg className="theme-toggle__icon theme-toggle__icon--moon" viewBox="0 0 20 20" width="12" height="12">
          <path d="M17 11.5 A7 7 0 1 1 8.5 3 A5.5 5.5 0 0 0 17 11.5 Z" fill="currentColor" />
        </svg>
        <span className="theme-toggle__thumb" />
      </span>
    </button>
  );
}
