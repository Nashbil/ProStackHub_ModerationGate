import { useState, useEffect } from "react";
import { getFlaggedLog, clearFlaggedLog, moderate } from "../api";
import { BENIGN_TEST_MESSAGES } from "../testMessages";
import "./Admin.css";

export default function Admin() {
  const [flagged, setFlagged] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [testResults, setTestResults] = useState(null);
  const [isTesting, setIsTesting] = useState(false);

  async function loadFlagged() {
    setIsLoading(true);
    try {
      const { flagged } = await getFlaggedLog();
      setFlagged(flagged);
    } catch {
      // eh, not critical if this fails
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadFlagged();
  }, []);

  async function handleClear() {
    await clearFlaggedLog();
    setFlagged([]);
  }

  async function runTestSuite() {
    setIsTesting(true);
    setTestResults(null);
    const results = [];
    for (const message of BENIGN_TEST_MESSAGES) {
      try {
        const result = await moderate(message);
        results.push({ message, ...result });
      } catch (err) {
        results.push({ message, flagged: null, error: err.message });
      }
    }
    setIsTesting(false);
    setTestResults(results);
    loadFlagged();
  }

  const falsePositives = testResults?.filter((r) => r.flagged === true) ?? [];
  const falsePositiveRate = testResults ? ((falsePositives.length / testResults.length) * 100).toFixed(1) : null;

  return (
    <div className="admin">
      <section className="admin__section">
        <div className="admin__section-header">
          <h2>Flagged messages</h2>
          <div className="admin__actions">
            <button onClick={loadFlagged}>Refresh</button>
            {flagged.length > 0 && <button onClick={handleClear}>Clear log</button>}
          </div>
        </div>

        {isLoading && <p className="admin__empty">loading…</p>}
        {!isLoading && flagged.length === 0 && <p className="admin__empty">nothing flagged yet</p>}

        <div className="admin__log">
          {flagged.map((f) => (
            <div key={f.id} className="admin-entry">
              <div className="admin-entry__meta">
                <span className="admin-entry__category">{f.category?.replace(/_/g, " ")}</span>
                <span className="admin-entry__time">{new Date(f.timestamp).toLocaleString()}</span>
              </div>
              <p className="admin-entry__message">"{f.message}"</p>
              <p className="admin-entry__reason">{f.reason}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="admin__section">
        <div className="admin__section-header">
          <h2>False-positive test</h2>
          <button onClick={runTestSuite} disabled={isTesting}>
            {isTesting ? "Running…" : `Run ${BENIGN_TEST_MESSAGES.length}-message test`}
          </button>
        </div>

        <p className="admin__hint">
          runs a batch of clearly benign messages through the classifier - anything flagged here
          is a false positive
        </p>

        {testResults && (
          <>
            <div className={`admin__rate ${falsePositives.length > 0 ? "admin__rate--warn" : "admin__rate--good"}`}>
              false-positive rate: {falsePositiveRate}% ({falsePositives.length} of {testResults.length})
            </div>
            <div className="admin__log">
              {testResults.map((r, i) => (
                <div key={i} className={`admin-entry ${r.flagged ? "admin-entry--fp" : ""}`}>
                  <div className="admin-entry__meta">
                    <span className={r.flagged ? "admin-entry__category" : "admin-entry__pass"}>
                      {r.flagged === null ? "error" : r.flagged ? "flagged (false positive)" : "passed"}
                    </span>
                  </div>
                  <p className="admin-entry__message">"{r.message}"</p>
                  {r.reason && <p className="admin-entry__reason">{r.reason}</p>}
                </div>
              ))}
            </div>
          </>
        )}
      </section>
    </div>
  );
}
