import { useState, useEffect } from "react";
import { getFlaggedLog, clearFlaggedLog, moderate, getStats } from "../api";
import { BENIGN_TEST_MESSAGES } from "../testMessages";
import "./Admin.css";

function timeAgo(iso) {
  const diffMs = Date.now() - new Date(iso).getTime();
  const mins = Math.floor(diffMs / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const hours = Math.floor(mins / 60);
  if (hours < 24) return `${hours}h ago`;
  return new Date(iso).toLocaleDateString();
}

export default function Admin() {
  const [flagged, setFlagged] = useState([]);
  const [stats, setStats] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [testResults, setTestResults] = useState(null);
  const [isTesting, setIsTesting] = useState(false);

  async function loadData() {
    setIsLoading(true);
    try {
      const [{ flagged: flaggedList }, statsResult] = await Promise.all([getFlaggedLog(), getStats()]);
      setFlagged(flaggedList);
      setStats(statsResult);
    } catch {
      // best-effort — admin view failing to load isn't the critical path
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    loadData();
  }, []);

  async function handleClear() {
    await clearFlaggedLog();
    setFlagged([]);
    const statsResult = await getStats();
    setStats(statsResult);
  }

  async function runTestSuite() {
    setIsTesting(true);
    setTestResults(null);
    const results = [];
    for (const message of BENIGN_TEST_MESSAGES) {
      try {
        const result = await moderate(message);
        results.push({ message, ...result });
      } catch (err) {
        results.push({ message, flagged: null, error: err.message });
      }
    }
    setIsTesting(false);
    setTestResults(results);
    loadData();
  }

  const falsePositives = testResults?.filter((r) => r.flagged === true) ?? [];
  const falsePositiveRate = testResults ? ((falsePositives.length / testResults.length) * 100).toFixed(1) : null;

  const safeCount = stats ? Math.max(0, stats.totalProcessed - stats.flaggedCount) : 0;
  const flagRate = stats && stats.totalProcessed > 0 ? ((stats.flaggedCount / stats.totalProcessed) * 100).toFixed(1) : "0.0";

  return (
    <div className="admin">
      <section className="admin__section">
        <h2>Overview</h2>
        {isLoading && !stats ? (
          <p className="admin__empty">loading…</p>
        ) : (
          <div className="stat-grid">
            <div className="stat-card">
              <p className="stat-card__label">Total Moderated</p>
              <p className="stat-card__value">{stats?.totalProcessed ?? 0}</p>
            </div>
            <div className="stat-card stat-card--danger">
              <p className="stat-card__label">Flagged</p>
              <p className="stat-card__value">{stats?.flaggedCount ?? 0}</p>
            </div>
            <div className="stat-card stat-card--safe">
              <p className="stat-card__label">Safe</p>
              <p className="stat-card__value">{safeCount}</p>
            </div>
            <div className="stat-card">
              <p className="stat-card__label">Flag Rate</p>
              <p className="stat-card__value">{flagRate}%</p>
            </div>
          </div>
        )}
      </section>

      <section className="admin__section">
        <div className="admin__section-header">
          <h2>Flagged Content</h2>
          <div className="admin__actions">
            <button onClick={loadData}>Refresh</button>
            {flagged.length > 0 && <button onClick={handleClear}>Clear log</button>}
          </div>
        </div>

        {!isLoading && flagged.length === 0 && (
          <div className="admin__empty-state">
            <svg viewBox="0 0 32 36" width="26" height="30">
              <path d="M16 2 L29 7 V17 C29 25.5 23.5 31.5 16 34 C8.5 31.5 3 25.5 3 17 V7 Z" fill="none" stroke="var(--safe)" strokeWidth="1.6" />
              <path d="M10 17.5 L14.2 21.5 L22 12.5" fill="none" stroke="var(--safe)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <p className="admin__empty-title">No flagged content</p>
            <p className="admin__empty-sub">Everything looks clear for now.</p>
          </div>
        )}

        <div className="flagged-list">
          {flagged.map((f) => (
            <div key={f.id} className="flagged-card">
              <div className="flagged-card__header">
                <span className="flagged-card__category">{f.category?.replace(/_/g, " ")}</span>
                <span className="flagged-card__time">{timeAgo(f.timestamp)}</span>
              </div>
              <p className="flagged-card__message">&ldquo;{f.message}&rdquo;</p>
              <p className="flagged-card__reason">{f.reason}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="admin__section">
        <div className="admin__section-header">
          <h2>False-Positive Test</h2>
          <button className="admin__run-btn" onClick={runTestSuite} disabled={isTesting}>
            {isTesting ? "Running…" : `Run ${BENIGN_TEST_MESSAGES.length}-message test`}
          </button>
        </div>

        <p className="admin__hint">
          Runs a set of clearly benign messages through the classifier. Anything flagged here is
          a false positive.
        </p>

        {testResults && (
          <>
            <div className={`rate-card ${falsePositives.length > 0 ? "rate-card--warn" : "rate-card--good"}`}>
              <div className="rate-card__text">
                False-positive rate: {falsePositiveRate}% ({falsePositives.length} of {testResults.length})
              </div>
              <div className="rate-card__track">
                <div className="rate-card__fill" style={{ width: `${falsePositiveRate}%` }} />
              </div>
            </div>
            <div className="flagged-list">
              {testResults.map((r, i) => (
                <div key={i} className={`flagged-card ${r.flagged ? "flagged-card--fp" : "flagged-card--pass"}`}>
                  <div className="flagged-card__header">
                    <span className={r.flagged ? "flagged-card__category" : "flagged-card__pass-label"}>
                      {r.flagged === null ? "Error" : r.flagged ? "Flagged (false positive)" : "Passed"}
                    </span>
                  </div>
                  <p className="flagged-card__message">&ldquo;{r.message}&rdquo;</p>
                  {r.reason && <p className="flagged-card__reason">{r.reason}</p>}
                </div>
              ))}
            </div>
          </>
        )}
      </section>
    </div>
  );
}
