import ThemeToggle from "./ThemeToggle";
import StatusIndicator from "./StatusIndicator";
import "./Navbar.css";

export default function Navbar({ view, onViewChange, theme, onToggleTheme }) {
  return (
    <header className="navbar">
      <div className="navbar__brand">
        <svg viewBox="0 0 32 36" className="navbar__shield">
          <path
            d="M16 2 L29 7 V17 C29 25.5 23.5 31.5 16 34 C8.5 31.5 3 25.5 3 17 V7 Z"
            fill="var(--accent-soft)"
            stroke="var(--accent)"
            strokeWidth="1.6"
          />
          <path d="M10 17.5 L14.2 21.5 L22 12.5" fill="none" stroke="var(--accent)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="navbar__check" />
        </svg>
        <div>
          <h1>ModerationGate</h1>
          <p>AI-powered content moderation</p>
        </div>
      </div>

      <div className="navbar__right">
        <StatusIndicator />
        <nav className="navbar__nav">
          <button className={view === "chat" ? "is-active" : ""} onClick={() => onViewChange("chat")}>
            Moderation
          </button>
          <button className={view === "admin" ? "is-active" : ""} onClick={() => onViewChange("admin")}>
            Admin
          </button>
        </nav>
        <ThemeToggle theme={theme} onToggle={onToggleTheme} />
      </div>
    </header>
  );
}
