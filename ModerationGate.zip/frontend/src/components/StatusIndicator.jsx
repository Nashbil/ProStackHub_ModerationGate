import { useEffect, useState } from "react";
import { checkHealth } from "../api";
import "./StatusIndicator.css";

export default function StatusIndicator() {
  const [online, setOnline] = useState(null);

  useEffect(() => {
    let cancelled = false;

    async function poll() {
      const ok = await checkHealth();
      if (!cancelled) setOnline(ok);
    }

    poll();
    const interval = setInterval(poll, 20000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, []);

  const label = online === null ? "Checking…" : online ? "Moderation Engine Online" : "Engine Unreachable";

  return (
    <span className={`status-pill ${online === false ? "is-offline" : ""} ${online === null ? "is-pending" : ""}`}>
      <span className="status-pill__dot" />
      {label}
    </span>
  );
}
