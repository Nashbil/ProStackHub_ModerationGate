import { useState, useRef, useEffect } from "react";
import { moderate } from "../api";
import "./Chat.css";

function ShieldIcon({ status }) {
  return (
    <svg viewBox="0 0 32 36" className={`shield-icon shield-icon--${status}`}>
      <path
        d="M16 2 L29 7 V17 C29 25.5 23.5 31.5 16 34 C8.5 31.5 3 25.5 3 17 V7 Z"
        className="shield-icon__body"
        fill="none"
        strokeWidth="2"
      />
      {status === "checking" && <span className="shield-icon__scan" />}
      {status === "allowed" && (
        <path d="M10 17.5 L14.2 21.5 L22 12.5" fill="none" stroke="var(--safe)" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" />
      )}
      {(status === "blocked" || status === "error") && (
        <path d="M11 11 L21 23 M21 11 L11 23" fill="none" stroke="var(--danger)" strokeWidth="2.2" strokeLinecap="round" />
      )}
    </svg>
  );
}

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isChecking, setIsChecking] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function analyze(text, pendingId) {
    setIsChecking(true);
    try {
      const result = await moderate(text);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === pendingId
            ? { ...m, status: result.flagged ? "blocked" : "allowed", category: result.category, reason: result.reason }
            : m
        )
      );
    } catch (err) {
      setMessages((prev) => prev.map((m) => (m.id === pendingId ? { ...m, status: "error", reason: err.message } : m)));
    } finally {
      setIsChecking(false);
    }
  }

  async function handleSend(e) {
    e.preventDefault();
    const text = input.trim();
    if (!text || isChecking) return;

    setInput("");
    const pendingId = Date.now();
    setMessages((prev) => [...prev, { id: pendingId, text, status: "checking" }]);
    analyze(text, pendingId);
  }

  function handleRetry(id, text) {
    setMessages((prev) => prev.map((m) => (m.id === id ? { ...m, status: "checking" } : m)));
    analyze(text, id);
  }

  return (
    <div className="chat">
      <p className="chat__eyebrow">Enter content to analyze</p>

      <div className="chat__log">
        {messages.length === 0 && (
          <div className="chat__empty">
            <svg viewBox="0 0 32 36" className="chat__empty-shield">
              <path
                d="M16 2 L29 7 V17 C29 25.5 23.5 31.5 16 34 C8.5 31.5 3 25.5 3 17 V7 Z"
                fill="none"
                stroke="var(--accent)"
                strokeWidth="1.6"
              />
            </svg>
            <p className="chat__empty-title">Ready for analysis</p>
            <p className="chat__empty-sub">Type a message below to see it checked against the moderation gate.</p>
          </div>
        )}

        {messages.map((m) => (
          <div key={m.id} className={`case-card case-card--${m.status}`}>
            <ShieldIcon status={m.status} />
            <div className="case-card__body">
              <p className="case-card__text">{m.text}</p>

              {m.status === "checking" && <p className="case-card__meta case-card__meta--checking">Analyzing content&hellip;</p>}

              {m.status === "allowed" && (
                <div className="result-chip result-chip--safe">
                  <span>SAFE</span>
                  <span className="result-chip__detail">Content appears safe</span>
                </div>
              )}

              {m.status === "blocked" && (
                <div className="result-chip result-chip--blocked">
                  <span>BLOCKED</span>
                  <span className="result-chip__detail">Content violates moderation policy</span>
                  <div className="case-card__meta-row">
                    <span className="case-card__category">{m.category?.replace(/_/g, " ")}</span>
                  </div>
                  <p className="case-card__reason">{m.reason}</p>
                </div>
              )}

              {m.status === "error" && (
                <div className="result-chip result-chip--error">
                  <span>ANALYSIS UNAVAILABLE</span>
                  <span className="result-chip__detail">We couldn't process this content right now.</span>
                  <button className="case-card__retry" onClick={() => handleRetry(m.id, m.text)}>
                    Try again
                  </button>
                </div>
              )}
            </div>
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <form className="chat__composer" onSubmit={handleSend}>
        <input
          type="text"
          placeholder="Type a message to analyze…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button type="submit" disabled={!input.trim() || isChecking}>
          {isChecking ? "Analyzing…" : "Analyze Content"}
        </button>
      </form>
    </div>
  );
}
