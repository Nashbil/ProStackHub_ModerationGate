import { useState, useRef, useEffect } from "react";
import { moderate } from "../api";
import "./Chat.css";

export default function Chat() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState("");
  const [isChecking, setIsChecking] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  async function handleSend(e) {
    e.preventDefault();
    const text = input.trim();
    if (!text || isChecking) return;

    setInput("");
    setIsChecking(true);

    const pendingId = Date.now();
    setMessages((prev) => [...prev, { id: pendingId, text, status: "checking" }]);

    try {
      const result = await moderate(text);
      setMessages((prev) =>
        prev.map((m) =>
          m.id === pendingId
            ? { ...m, status: result.flagged ? "blocked" : "allowed", category: result.category, reason: result.reason }
            : m
        )
      );
    } catch (err) {
      setMessages((prev) => prev.map((m) => (m.id === pendingId ? { ...m, status: "error", reason: err.message } : m)));
    } finally {
      setIsChecking(false);
    }
  }

  return (
    <div className="chat">
      <div className="chat__log">
        {messages.length === 0 && (
          <p className="chat__empty">every message here gets checked by gemini before it shows up</p>
        )}
        {messages.map((m) => (
          <div key={m.id} className={`chat-msg chat-msg--${m.status}`}>
            {m.status === "allowed" && <span className="chat-msg__text">{m.text}</span>}
            {m.status === "checking" && <span className="chat-msg__text chat-msg__text--pending">{m.text}</span>}
            {m.status === "blocked" && (
              <div className="chat-msg__blocked">
                <span className="chat-msg__badge chat-msg__badge--block">Blocked</span>
                <span className="chat-msg__category">{m.category?.replace(/_/g, " ")}</span>
                <p className="chat-msg__reason">{m.reason}</p>
              </div>
            )}
            {m.status === "error" && (
              <div className="chat-msg__blocked">
                <span className="chat-msg__badge chat-msg__badge--error">Error</span>
                <p className="chat-msg__reason">{m.reason}</p>
              </div>
            )}
            {m.status === "checking" && <span className="chat-msg__badge chat-msg__badge--checking">Checking…</span>}
            {m.status === "allowed" && <span className="chat-msg__badge chat-msg__badge--pass">Allowed</span>}
          </div>
        ))}
        <div ref={endRef} />
      </div>

      <form className="chat__composer" onSubmit={handleSend}>
        <input
          type="text"
          placeholder="Type a message…"
          value={input}
          onChange={(e) => setInput(e.target.value)}
        />
        <button type="submit" disabled={!input.trim() || isChecking}>Send</button>
      </form>
    </div>
  );
}
