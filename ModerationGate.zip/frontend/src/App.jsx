import { useState } from "react";
import Chat from "./components/Chat";
import Admin from "./components/Admin";
import "./App.css";

export default function App() {
  const [view, setView] = useState("chat");

  return (
    <div className="app">
      <header className="app__header">
        <div className="app__title">
          <span className="app__gate">⛨</span>
          <div>
            <h1>ModerationGate</h1>
            <p>every message gets checked before it shows up</p>
          </div>
        </div>
        <nav className="app__nav">
          <button className={view === "chat" ? "is-active" : ""} onClick={() => setView("chat")}>Chat</button>
          <button className={view === "admin" ? "is-active" : ""} onClick={() => setView("admin")}>Admin</button>
        </nav>
      </header>

      <main className="app__body">{view === "chat" ? <Chat /> : <Admin />}</main>
    </div>
  );
}
