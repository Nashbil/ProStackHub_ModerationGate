import { useState } from "react";
import { applyTheme } from "./theme";
import Navbar from "./components/Navbar";
import Chat from "./components/Chat";
import Admin from "./components/Admin";
import "./App.css";

export default function App() {
  const [view, setView] = useState("chat");
  const [theme, setTheme] = useState(() => document.documentElement.getAttribute("data-theme") || "light");

  function toggleTheme() {
    const next = theme === "dark" ? "light" : "dark";
    setTheme(next);
    applyTheme(next);
  }

  return (
    <div className="app stage-in">
      <Navbar view={view} onViewChange={setView} theme={theme} onToggleTheme={toggleTheme} />
      <main className="app__body">{view === "chat" ? <Chat /> : <Admin />}</main>
    </div>
  );
}
