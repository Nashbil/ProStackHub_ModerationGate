import "dotenv/config";
import express from "express";
import cors from "cors";
import moderateRouter from "./routes/moderate.js";
import adminRouter from "./routes/admin.js";

const app = express();
const PORT = process.env.PORT || 8789;
const CORS_ORIGIN = process.env.CORS_ORIGIN || "http://localhost:5175";

app.use(cors({ origin: CORS_ORIGIN.split(",").map((o) => o.trim()) }));
app.use(express.json({ limit: "1mb" }));

app.get("/health", (req, res) => {
  res.json({ status: "ok" });
});

app.use("/moderate", moderateRouter);
app.use("/admin", adminRouter);

app.use((err, req, res, next) => {
  console.error(err);
  res.status(500).json({ error: "something went wrong" });
});

app.listen(PORT, () => {
  console.log(`moderationgate backend running on http://localhost:${PORT}`);
});
