import { Router } from "express";
import { v4 as uuidv4 } from "uuid";
import { moderateMessage } from "../services/gemini.js";
import { logFlagged, recordProcessed } from "../services/flaggedStore.js";

const router = Router();

router.post("/", async (req, res) => {
  try {
    const { message } = req.body;

    if (!message || !message.trim()) {
      return res.status(400).json({ error: "message is required" });
    }

    if (message.length > 5000) {
      return res.status(413).json({ error: "message too long, keep it under 5000 chars" });
    }

    const result = await moderateMessage(message);
    recordProcessed();

    if (result.flagged) {
      logFlagged({
        id: uuidv4(),
        message,
        category: result.category,
        reason: result.reason,
        timestamp: new Date().toISOString(),
      });
    }

    res.json(result);
  } catch (err) {
    console.error("moderation error:", err);
    res.status(500).json({ error: err.message || "failed to moderate message" });
  }
});

export default router;
