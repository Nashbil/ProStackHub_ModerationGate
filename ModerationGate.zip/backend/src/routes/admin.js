import { Router } from "express";
import { getFlaggedLog, clearFlaggedLog, getStats } from "../services/flaggedStore.js";

const router = Router();

router.get("/flagged", (req, res) => {
  res.json({ flagged: getFlaggedLog() });
});

router.delete("/flagged", (req, res) => {
  clearFlaggedLog();
  res.json({ success: true });
});

router.get("/stats", (req, res) => {
  res.json(getStats());
});

export default router;
