import { Router } from "express";
import { getFlaggedLog, clearFlaggedLog } from "../services/flaggedStore.js";

const router = Router();

router.get("/flagged", (req, res) => {
  res.json({ flagged: getFlaggedLog() });
});

router.delete("/flagged", (req, res) => {
  clearFlaggedLog();
  res.json({ success: true });
});

export default router;
