// calls gemini to classify messages as safe or flagged

const BASE_URL = "https://generativelanguage.googleapis.com/v1beta";
const CHAT_MODEL = process.env.GEMINI_CHAT_MODEL || "gemini-3.5-flash-lite";

function getApiKey() {
  const key = process.env.GEMINI_API_KEY;
  if (!key) {
    throw new Error("GEMINI_API_KEY is not set. Copy .env.example to .env and add your key.");
  }
  return key;
}

async function fetchWithRetry(url, options, retries = 3, baseDelay = 1000) {
  for (let attempt = 0; attempt <= retries; attempt++) {
    const res = await fetch(url, options);
    if (res.ok) return res;
    if ((res.status === 429 || res.status === 503) && attempt < retries) {
      const delay = baseDelay * 2 ** attempt;
      console.log(`gemini returned ${res.status}, retrying in ${delay}ms...`);
      await new Promise((r) => setTimeout(r, delay));
      continue;
    }
    return res;
  }
}

const CATEGORIES = [
  "harassment",
  "hate_speech",
  "violence",
  "sexual_content",
  "self_harm",
  "spam_or_scam",
  "illegal_activity",
];

export async function moderateMessage(message) {
  const apiKey = getApiKey();
  const url = `${BASE_URL}/models/${CHAT_MODEL}:generateContent?key=${apiKey}`;

  const prompt = `you're a content moderation classifier for a chat app. decide if the message below violates content policy.

categories: ${CATEGORIES.join(", ")}

be precise, don't over-flag. normal conversation, questions, complaints, mild frustration, casual profanity (not directed at someone), disagreement - none of that counts. only flag stuff that's actually harassing, hateful, violent, explicitly sexual, promotes self-harm, spam/scam, or illegal activity.

respond with ONLY json, no markdown fences, this exact shape:
{"flagged": boolean, "category": string or null, "reason": string or null}

not flagged -> {"flagged": false, "category": null, "reason": null}
flagged -> category must be one of the categories above, reason should be short (under 20 words) and specific

message:
"""
${message}
"""`;

  const res = await fetchWithRetry(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        temperature: 0,
      },
    }),
  });

  if (!res.ok) {
    const errBody = await res.text();
    throw new Error(`moderation call failed (${res.status}): ${errBody}`);
  }

  const data = await res.json();
  const rawText = data.candidates?.[0]?.content?.parts?.map((p) => p.text).join("") ?? "";
  if (!rawText) throw new Error("gemini returned an empty response");

  let parsed;
  try {
    parsed = JSON.parse(rawText);
  } catch {
    throw new Error(`gemini gave back non-json: ${rawText.slice(0, 200)}`);
  }

  return {
    flagged: Boolean(parsed.flagged),
    category: parsed.flagged ? parsed.category || "other" : null,
    reason: parsed.flagged ? parsed.reason || "no reason given" : null,
  };
}
