// in-memory log of flagged messages for the admin view, plus a running total
// of everything that's passed through moderation. resets on restart, fine for now

const flaggedLog = [];
let totalProcessed = 0;

export function logFlagged(entry) {
  flaggedLog.unshift(entry);
  if (flaggedLog.length > 500) flaggedLog.pop();
}

export function getFlaggedLog() {
  return flaggedLog;
}

export function clearFlaggedLog() {
  flaggedLog.length = 0;
}

export function recordProcessed() {
  totalProcessed += 1;
}

export function getStats() {
  return {
    totalProcessed,
    flaggedCount: flaggedLog.length,
  };
}
