// in-memory log of flagged messages for the admin view
// resets on restart, fine for now

const flaggedLog = [];

export function logFlagged(entry) {
  flaggedLog.unshift(entry);
  if (flaggedLog.length > 500) flaggedLog.pop();
}

export function getFlaggedLog() {
  return flaggedLog;
}

export function clearFlaggedLog() {
  flaggedLog.length = 0;
}
